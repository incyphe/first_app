(function () {
	// stupid stupid hack to force repaint :(
	document.body.style.display = "none";
	document.body.offsetHeight;
	document.body.style.display = "";
	
    console.log("loading socket.js");
	
	const url = "http://127.0.0.1:17999";
	var socket;
	
	var body = document.body;
	var main = document.querySelector("main");
	var paperRipple = document.querySelector("paper-ripple");
	var selectedArtboardInformation = document.getElementById("selectedArtboardInformation");
	var selectedArtboardCount = document.getElementById("selectedArtboardCount");
	var selectedLayerCount = document.querySelector("#selectedLayerInformation strong");
	var selectedLayerGroupCount = document.querySelector("#selectedLayerGroupInformation strong");
	var skipCheckbox = document.querySelector('input[type="checkbox"]');
	var exportSelectedArtboards = document.getElementById("exportSelectedArtboards");
	var markAsAsset = document.getElementById("markAsAsset");
	var unmarkAsAsset = document.getElementById("unmarkAsAsset");
	var gotIt = document.getElementById("gotIt");
	var progress = document.getElementById("progress");
	var exportingOne = document.querySelector("#exportingOne span");
	var exportingMany = document.querySelector("#exportingMany span");
	var failedLayer = document.getElementById("failedLayer");
	var failedArtboard = document.getElementById("failedArtboard");
	var links = document.querySelectorAll("a");
	var report = document.getElementById("report");
	var zeplin = document.getElementById("zeplin");
	var closePluginUpdatedInfo = document.querySelector("#pluginUpdated img");
	var projectsDiv = document.getElementById("projects");
	var projectTemplate = document.getElementById("projectTemplate");
	var importToProjectButton = document.getElementById("importToProject");
	var cancelProjectSelection = document.getElementById("cancelProjectSelection");
	var updateScreens = document.getElementById("updateScreens");
	var cancelDensitySelection = document.getElementById("cancelDensitySelection");
	var chooseDensity = document.getElementById("chooseDensity");
	var androidDensities = document.getElementById("android");
	var organizationTemplate = document.getElementById("organizationTemplate");
	var organizationsDiv = document.getElementById("organizations");
	var selectProjectDiv = document.getElementById("selectProject");
	var organizationDropdown = document.getElementById("organizationDropdown");
	var selectedOrganizationTextInDropdown = document.getElementById("selectedOrganization");
	var selectProjectContent = document.getElementById("selectProjectContent");
	
	var logger;
	try {
		var path = require("path");
		var winston = require("winston");
		require('winston-daily-rotate-file');
		logger = new (winston.Logger)({
			transports: [
				 new (winston.transports.DailyRotateFile)({
					 filename: (function () {
						 if (process.platform === "win32") {
							 return path.resolve(process.env.APPDATA, "Zeplin", "io.zeplin.photoshop-panel.log");
						 } else if (process.platform === "darwin") {
							 return path.resolve(process.env.HOME, "Library", "Logs", "Zeplin", "io.zeplin.photoshop-panel.log");
						 }
					 })()
				 })
	        ]
		});
	} catch(err) {
		console.log(err);
		logger = {
			info: function () {
				console.log(Array.prototype.join.call(arguments, ", "));
			},
			error: function () {
				console.error(Array.prototype.join.call(arguments, ", "));
			}
		};
	}
	window.zplPanelLogger = logger; 
	window.onerror = function (message, source, lineno, colno, error) {
		logger.error("%s:%d:%d %s %j", source, lineno, colno, message, error, {});
		return true;
	};
	logger.info("logger is initialized");

	function getLastImportedProject() {
		return localStorage.getItem("lastImportedProject");
	}

	function setLastImportedProject(lastImportedProject) {
		localStorage.setItem("lastImportedProject", lastImportedProject);
	}

	function initSocket () {
		logger.info("connection to url: %s", url);
		socket = io.connect(url);

		getSocket().on("connect", function () {
			logger.info("connected to url: %s", url);
			body.className = "artboardSelection";
		});

		function onConnectError(error) {
			logger.error("connection error: %j", error, {});
			body.className = "connectionFailureDisplay";
		}

		getSocket().on("connect_error", onConnectError);
		getSocket().on("connect_timeout", onConnectError);

		getSocket().on("progress", function (data) {
			logger.info("generator sent progress: %j", data, {});
			body.classList.add("withProgress");
			var progressPercentage = Math.floor((data.count / data.total) * 100);
			progress.style.width = progressPercentage + "%";

		});

		getSocket().on("complete", function (data) {
			progress.style.width = "100%";
			logger.info("generator sent complete: %j", data, {});

			exportSelectedArtboards.disabled = false;
			skipCheckbox.disable = false;
			progress.style.width = "0%";
			body.classList.remove("exporting", "withProgress");
			body.classList.add("selectionDisplay");
		});

		getSocket().on("parseError", function (data) {
			logger.error("generator sent an error: %j", data.error, {});

			failedLayer.textContent = data.layerName;
			failedLayer.classList.toggle("hidden", !data.layerName);
			
			failedArtboard.textContent = data.artboardName;
			
			report.href = prepareReportHref(data.error.message, data.error.stack);

			exportSelectedArtboards.disabled = false;
			skipCheckbox.disable = false;
			progress.style.width = "0%";
			body.className = "failureDisplay";
		});

		getSocket().on("updateReady", function () {
			body.classList.add("pluginUpdated");
		});

		var emojiRegex = /(?:0\u20E3|1\u20E3|2\u20E3|3\u20E3|4\u20E3|5\u20E3|6\u20E3|7\u20E3|8\u20E3|9\u20E3|#\u20E3|\*\u20E3|\uD83C(?:\uDDE6\uD83C(?:\uDDE8|\uDDE9|\uDDEA|\uDDEB|\uDDEC|\uDDEE|\uDDF1|\uDDF2|\uDDF4|\uDDF6|\uDDF7|\uDDF8|\uDDF9|\uDDFA|\uDDFC|\uDDFD|\uDDFF)|\uDDE7\uD83C(?:\uDDE6|\uDDE7|\uDDE9|\uDDEA|\uDDEB|\uDDEC|\uDDED|\uDDEE|\uDDEF|\uDDF1|\uDDF2|\uDDF3|\uDDF4|\uDDF6|\uDDF7|\uDDF8|\uDDF9|\uDDFB|\uDDFC|\uDDFE|\uDDFF)|\uDDE8\uD83C(?:\uDDE6|\uDDE8|\uDDE9|\uDDEB|\uDDEC|\uDDED|\uDDEE|\uDDF0|\uDDF1|\uDDF2|\uDDF3|\uDDF4|\uDDF5|\uDDF7|\uDDFA|\uDDFB|\uDDFC|\uDDFD|\uDDFE|\uDDFF)|\uDDE9\uD83C(?:\uDDEA|\uDDEC|\uDDEF|\uDDF0|\uDDF2|\uDDF4|\uDDFF)|\uDDEA\uD83C(?:\uDDE6|\uDDE8|\uDDEA|\uDDEC|\uDDED|\uDDF7|\uDDF8|\uDDF9|\uDDFA)|\uDDEB\uD83C(?:\uDDEE|\uDDEF|\uDDF0|\uDDF2|\uDDF4|\uDDF7)|\uDDEC\uD83C(?:\uDDE6|\uDDE7|\uDDE9|\uDDEA|\uDDEB|\uDDEC|\uDDED|\uDDEE|\uDDF1|\uDDF2|\uDDF3|\uDDF5|\uDDF6|\uDDF7|\uDDF8|\uDDF9|\uDDFA|\uDDFC|\uDDFE)|\uDDED\uD83C(?:\uDDF0|\uDDF2|\uDDF3|\uDDF7|\uDDF9|\uDDFA)|\uDDEE\uD83C(?:\uDDE8|\uDDE9|\uDDEA|\uDDF1|\uDDF2|\uDDF3|\uDDF4|\uDDF6|\uDDF7|\uDDF8|\uDDF9)|\uDDEF\uD83C(?:\uDDEA|\uDDF2|\uDDF4|\uDDF5)|\uDDF0\uD83C(?:\uDDEA|\uDDEC|\uDDED|\uDDEE|\uDDF2|\uDDF3|\uDDF5|\uDDF7|\uDDFC|\uDDFE|\uDDFF)|\uDDF1\uD83C(?:\uDDE6|\uDDE7|\uDDE8|\uDDEE|\uDDF0|\uDDF7|\uDDF8|\uDDF9|\uDDFA|\uDDFB|\uDDFE)|\uDDF2\uD83C(?:\uDDE6|\uDDE8|\uDDE9|\uDDEA|\uDDEB|\uDDEC|\uDDED|\uDDF0|\uDDF1|\uDDF2|\uDDF3|\uDDF4|\uDDF5|\uDDF6|\uDDF7|\uDDF8|\uDDF9|\uDDFA|\uDDFB|\uDDFC|\uDDFD|\uDDFE|\uDDFF)|\uDDF3\uD83C(?:\uDDE6|\uDDE8|\uDDEA|\uDDEB|\uDDEC|\uDDEE|\uDDF1|\uDDF4|\uDDF5|\uDDF7|\uDDFA|\uDDFF)|\uDDF4\uD83C\uDDF2|\uDDF5\uD83C(?:\uDDE6|\uDDEA|\uDDEB|\uDDEC|\uDDED|\uDDF0|\uDDF1|\uDDF2|\uDDF3|\uDDF7|\uDDF8|\uDDF9|\uDDFC|\uDDFE)|\uDDF6\uD83C\uDDE6|\uDDF7\uD83C(?:\uDDEA|\uDDF4|\uDDF8|\uDDFA|\uDDFC)|\uDDF8\uD83C(?:\uDDE6|\uDDE7|\uDDE8|\uDDE9|\uDDEA|\uDDEC|\uDDED|\uDDEE|\uDDEF|\uDDF0|\uDDF1|\uDDF2|\uDDF3|\uDDF4|\uDDF7|\uDDF8|\uDDF9|\uDDFB|\uDDFD|\uDDFE|\uDDFF)|\uDDF9\uD83C(?:\uDDE6|\uDDE8|\uDDE9|\uDDEB|\uDDEC|\uDDED|\uDDEF|\uDDF0|\uDDF1|\uDDF2|\uDDF3|\uDDF4|\uDDF7|\uDDF9|\uDDFB|\uDDFC|\uDDFF)|\uDDFA\uD83C(?:\uDDE6|\uDDEC|\uDDF2|\uDDF8|\uDDFE|\uDDFF)|\uDDFB\uD83C(?:\uDDE6|\uDDE8|\uDDEA|\uDDEC|\uDDEE|\uDDF3|\uDDFA)|\uDDFC\uD83C(?:\uDDEB|\uDDF8)|\uDDFD\uD83C\uDDF0|\uDDFE\uD83C(?:\uDDEA|\uDDF9)|\uDDFF\uD83C(?:\uDDE6|\uDDF2|\uDDFC)))|[\xA9\xAE\u203C\u2049\u2122\u2139\u2194-\u2199\u21A9\u21AA\u231A\u231B\u2328\u23CF\u23E9-\u23F3\u23F8-\u23FA\u24C2\u25AA\u25AB\u25B6\u25C0\u25FB-\u25FE\u2600-\u2604\u260E\u2611\u2614\u2615\u2618\u261D\u2620\u2622\u2623\u2626\u262A\u262E\u262F\u2638-\u263A\u2648-\u2653\u2660\u2663\u2665\u2666\u2668\u267B\u267F\u2692-\u2694\u2696\u2697\u2699\u269B\u269C\u26A0\u26A1\u26AA\u26AB\u26B0\u26B1\u26BD\u26BE\u26C4\u26C5\u26C8\u26CE\u26CF\u26D1\u26D3\u26D4\u26E9\u26EA\u26F0-\u26F5\u26F7-\u26FA\u26FD\u2702\u2705\u2708-\u270D\u270F\u2712\u2714\u2716\u271D\u2721\u2728\u2733\u2734\u2744\u2747\u274C\u274E\u2753-\u2755\u2757\u2763\u2764\u2795-\u2797\u27A1\u27B0\u27BF\u2934\u2935\u2B05-\u2B07\u2B1B\u2B1C\u2B50\u2B55\u3030\u303D\u3297\u3299]|\uD83C[\uDC04\uDCCF\uDD70\uDD71\uDD7E\uDD7F\uDD8E\uDD91-\uDD9A\uDE01\uDE02\uDE1A\uDE2F\uDE32-\uDE3A\uDE50\uDE51\uDF00-\uDF21\uDF24-\uDF93\uDF96\uDF97\uDF99-\uDF9B\uDF9E-\uDFF0\uDFF3-\uDFF5\uDFF7-\uDFFF]|\uD83D[\uDC00-\uDCFD\uDCFF-\uDD3D\uDD49-\uDD4E\uDD50-\uDD67\uDD6F\uDD70\uDD73-\uDD79\uDD87\uDD8A-\uDD8D\uDD90\uDD95\uDD96\uDDA5\uDDA8\uDDB1\uDDB2\uDDBC\uDDC2-\uDDC4\uDDD1-\uDDD3\uDDDC-\uDDDE\uDDE1\uDDE3\uDDEF\uDDF3\uDDFA-\uDE4F\uDE80-\uDEC5\uDECB-\uDED0\uDEE0-\uDEE5\uDEE9\uDEEB\uDEEC\uDEF0\uDEF3]|\uD83E[\uDD10-\uDD18\uDD80-\uDD84\uDDC0]/g;
		function handleProjects(projects) {
			body.className = "projectSelection";
			projectsDiv.innerHTML = "";
			importToProjectButton.disabled = true;
			
			if (selectProjectDiv.classList.contains("designerWithOrganization")) {
				selectProjectDiv.classList.remove("gettingOrganizationProjects");
				cancelProjectSelection.disabled = false;
				organizationDropdown.disabled = false;
			}
			
			var lastImportedProject = getLastImportedProject();

			body.classList.toggle("noProjects", !projects.length);

			var projectToSelect = projects.reduce(function (prev, project, index) {
				var newProject = document.importNode(projectTemplate.content, true);

				newProject.querySelector(".projectName").textContent = project.name.replace(emojiRegex, '').trim();

				newProject.querySelector(".project").dataset.type = project.type;
				
				newProject.querySelector(".project").dataset.pid = project.pid;
				newProject.querySelector(".project").dataset.density = project.density;
				
				newProject.querySelector(".projectIcon").dataset.type = project.icon.type;
				
				newProject.querySelector(".project").dataset.index = index;

				projectsDiv.appendChild(newProject);
				if (prev !== -1) {
					return prev;
				} else if (lastImportedProject && lastImportedProject === project.pid) {
					return index;
				} else {
					return prev;
				}
			}, -1);

			selectedProjectIndex = undefined;
			if (projectToSelect !== -1) {
				selectProject(projectToSelect);
			}
		}
		getSocket().on("projects", function (projectsData) {
			var projects = JSON.parse(projectsData);
			handleProjects(projects);
		});
		getSocket().on("projectsWithOrganizations", function (data) {
			var dataJSON = JSON.parse(data);
			
			var projects = dataJSON.projects;
			var organizations = dataJSON.organizations;
			var profiles = dataJSON.profiles;
			
			if (organizations && organizations.length > 0) {
				organizationsDiv.innerHTML = "";
				selectedOrganizationTextInDropdown.classList.remove("nonPersonal");
				selectProjectDiv.classList.remove("listingOrganizationProjects");
				body.classList.remove("userCantUploadDesigns");
				selectedOrganizationTextInDropdown.textContent = "Personal projects";
				
				var newOrganization = document.importNode(organizationTemplate.content, true);
				
				newOrganization.querySelector(".organizationName").textContent = "Personal projects";
				newOrganization.querySelector(".organization").classList.add("selected");
				newOrganization.querySelector(".organization").dataset.oid = "user";
				
				organizationsDiv.appendChild(newOrganization);
				
				organizations.forEach(function (organization) {
					var newOrganization = document.importNode(organizationTemplate.content, true);
					
					newOrganization.querySelector(".organizationName").textContent = organization.name.replace(emojiRegex, '').trim();
					newOrganization.querySelector(".organization").dataset.oid = organization.oid;
					if (profiles[organization.oid]) {
						newOrganization.querySelector(".organization").dataset.userRole = profiles[organization.oid];
					}

					organizationsDiv.appendChild(newOrganization);
				});
				selectProjectDiv.classList.add("designerWithOrganization");
			}
			
			handleProjects(projects);
		});
		
		getSocket().on("zeplinError", function (error) {
			logger.error("error recevied for zeplinError: %j", error, {});
			var el, gettingProjectsFailedTitle, planErrorText;
			if (selectProjectDiv.classList.contains("gettingOrganizationProjects")) {
				el = selectProjectDiv;
				el.classList.add("gettingProjectsFailed");
				el.classList.remove("gettingOrganizationProjects");
				gettingProjectsFailedTitle = el.querySelector(".gettingProjectsFailedTitle strong");
				planErrorText = el.querySelector(".planErrorText");
			} else {
				el = body;
				el.className = "gettingProjectsFailed";
				gettingProjectsFailedTitle = document.querySelector("body > .gettingProjectsFailedContent .gettingProjectsFailedTitle strong");
				planErrorText = document.querySelector("body > .gettingProjectsFailedContent .planErrorText");
			}
			
			el.classList.toggle("timeoutError", error.type === "timeout");
			el.classList.toggle("zeplinTokenError", error.type === "token_not_found");
			el.classList.toggle("planError", error.type === "plan");
			if (error.type === "plan") {
				gettingProjectsFailedTitle.textContent = error.title;
				planErrorText.textContent = error.message;
				localStorage.removeItem("lastImportedProject");
			}
		});
	}
	window.initSocket = initSocket;
	
	function openInDefaultBrowser (e) {
		e.preventDefault();
		window.cep.util.openURLInDefaultBrowser(e.target.href);
	}
	
	zeplin.addEventListener("click", function () {
		window.cep.util.openURLInDefaultBrowser("https://zeplin.io");
	});
	
	for(var i = 0; i < links.length; i++) {
		links[i].addEventListener("click", openInDefaultBrowser); 
	}
	
	function getSocket() {
		if (!socket) {
			initSocket();
		}
		return socket;
	}
	
	function prepareReportHref(error, stack) {
		return encodeURI("mailto:support@zeplin.io?subject=Photoshop Export Error&body=I just got an error when exporting artboards from Photoshop:\n\n" + (error ? error : "") + (stack ? "\n\n" + stack : ""));
	}
	
	function onClickExport() {
		getSocket().emit("initiate");
		body.className = "gettingProjects";
	}
	
	var selectedLayers = [];
	function updateSelectionInfo(selection, artboards) {
		exportSelectedArtboards.disabled = false;
		skipCheckbox.disable = false;
		selectedLayers = selection;

		if (selection) {
			var artboardCount = artboards.length;
			processArtboardSelection(artboardCount);
			main.dataset.artboardCount = artboardCount;
			
			var layers = selection.filter(function (item) {
				return item.type === "layer";
			});
			var layerGroups = selection.filter(function (item) {
				return item.type === "layerSection";
			});
			
			if (artboardCount === 1) {
				exportingOne.textContent = artboards[0].name;
			} else if (artboardCount > 1) {
				exportingMany.textContent = artboardCount;
			}
			
			selectedLayerCount.textContent = selection.length;
			selectedLayerCount.classList.toggle("manyLayers", selection.length > 1);

			selectedLayerGroupCount.textContent = layerGroups.length;
			selectedLayerGroupCount.classList.toggle("manyLayerGroups", layerGroups.length > 1);

			if (layerGroups.length >= 1 && artboardCount === 1 && layers.length === 0) {
				var exportableLayerGroupCount = layerGroups.filter(function (layerGroup) {
					return layerGroup.exportable;
				}).length;
				
				if (exportableLayerGroupCount > 0) {
					body.classList.add("markLayerGroupAsAsset");	
				} else {
					body.classList.add("unmarkLayerGroupAsAsset");
				}
				
				if (layerGroups.length === 1) {
					body.classList.add("oneLayerGroup");
					skipCheckbox.checked = !layerGroups[0].skippable;
				}
			} else if (selection.length > 0) {
				var exportableLayerCount = selection.filter(function (layer) {
					return layer.exportable;
				}).length;
				
				if (exportableLayerCount > 0) {
					body.classList.add("markLayerAsAsset");
				} else {
					body.classList.add("unmarkLayerAsAsset");
				}
			}
		}
	}
	
	function processArtboardSelection(artboardCount) {
		var addPluginUpdated = body.classList.contains("pluginUpdated");
		if (artboardCount > 0) {
			!body.classList.contains("gettingProjects") && (body.className = "selectionDisplay");
			selectedArtboardCount.textContent = artboardCount; 
			if (artboardCount > 1) {
				selectedArtboardInformation.dataset.many = true;
			} else {
				delete selectedArtboardInformation.dataset.many;
			}
		} else {
			!body.classList.contains("gettingProjects") && (body.className = "artboardSelection");
		}
		!body.classList.contains("gettingProjects") && body.classList.toggle("pluginUpdated", addPluginUpdated);
	}

    function getFirstScrollableParent(element) {
        var container = element.parentElement;

        // find first scrollable container
        while (container && container.scrollHeight <= container.clientHeight) {
            container = container.parentElement;
        }

        return container;
    }
	
	function scrollIfNecessary(element, container) {
        container = container || getFirstScrollableParent(element);

        if (!container) {
            return;
        }

        var elementRect = element.getBoundingClientRect(),
            containerRect = container.getBoundingClientRect();

        if (elementRect.top < containerRect.top) {
            container.scrollTop -= containerRect.top - elementRect.top;
        } else if (elementRect.bottom > containerRect.bottom) {
            container.scrollTop += elementRect.bottom - containerRect.bottom;
        }
    }
	
    var selectedProjectIndex;
    function selectProject(index) {
        var selectedProject;
        if (selectedProjectIndex !== undefined) {
            selectedProject = projectsDiv.querySelector('.project[data-index="' + selectedProjectIndex + '"]');
            selectedProject.classList.remove("selected");
        }

        selectedProjectIndex = parseInt(index, 10);
        selectedProject = projectsDiv.querySelector('.project[data-index="' + selectedProjectIndex + '"]');
        selectedProject.classList.add("selected");
        
        var container = selectProjectDiv.classList.contains("designerWithOrganization") ? selectProjectContent : projectsDiv; 
        scrollIfNecessary(selectedProject, container);

        importToProjectButton.disabled = false;
    }
    
    function importToProject(project) {
    	
    	setLastImportedProject(project.dataset.pid);
		
    	if (project.dataset.density === "unknown") {
			body.className = "densitySelection";
			body.classList.add(project.dataset.type);
			return;
		}

		getSocket().emit("export", {
			pid: project.dataset.pid,
			density: project.dataset.density,
			type: project.dataset.type,
			replace: updateScreens.checked
		});
		
		exportSelectedArtboards.disabled = true;
		skipCheckbox.disable = true;
		
		body.className = "selectionDisplay";
		body.classList.add("exporting");
    }

    function goToSelectionDisplay() {		
		exportSelectedArtboards.disabled = false;
		skipCheckbox.disable = false;
		
		body.className = "selectionDisplay";
    }

	function repaintAndroidDensities() {
		var scrollTop = android.parentElement.scrollTop;
		android.style.display = "none";
		android.offsetHeight;
		android.style.display = "";
		android.parentElement.scrollTop = scrollTop;
	}
	
	function getOrganizationProjects(organizationEl) {
		var data;
		if (organizationEl.dataset.oid !== "user") {
			data = {
				oid: organizationEl.dataset.oid
			};
		}
		getSocket().emit("initiate", data);
		selectProjectDiv.classList.add("gettingOrganizationProjects");
		organizationDropdown.disabled = true;
		importToProjectButton.disabled = true;
		cancelProjectSelection.disabled = true;
	}
	
	window.listenDocumentChanges = function () {
		getSocket().on("activeDocumentChanged", function (data) {
			logger.info("activeDocumentChanged: %j", data, {});
			updateSelectionInfo(data.selection, data.artboards);
		});
	}
	
	markAsAsset.addEventListener("click", function (ev) {
		getSocket().emit("rename", {
			export: true, 
			skip: false, 
			layers: selectedLayers, 
			checked: true
		});	
	});
	
	unmarkAsAsset.addEventListener("click", function (ev) {
		getSocket().emit("rename", {
			export: true, 
			skip: false, 
			layer: selectedLayers, 
			checked: false
		});	
	});
	
	skipCheckbox.addEventListener ("change", function (ev) {
		getSocket().emit("rename", {
			export: false, 
			skip: true, 
			layers: selectedLayers, 
			checked: ev.target.checked
		});	
	});
	
	gotIt.addEventListener("click", function (ev) {
		body.className = "selectionDisplay";
	});
	
	exportSelectedArtboards.addEventListener("click", onClickExport);
	
	closePluginUpdatedInfo.addEventListener("click", function () {
		body.classList.remove("pluginUpdated");
	});
	
	projectsDiv.addEventListener("click", function (ev) {
		var project = ev.target;
		
		while (project && !project.classList.contains("project")) {
			project = project.parentElement;
		}
		
		if (!project) {
			return;
		}
		
		selectProject(project.dataset.index);
	});
	
	projectsDiv.addEventListener("dblclick", function (ev) {
		var project = ev.target;
		
		while (project && !project.classList.contains("project")) {
			project = project.parentElement;
		}
		
		if (!project) {
			return;
		}
		
		importToProject(project);
	});
	
	importToProjectButton.addEventListener("click", function (ev) {
		var project = projectsDiv.querySelector(".project.selected");
		
		if (!project) {
			return;
		}
		
		importToProject(project);
	});
	
	
	cancelProjectSelection.addEventListener("click", function () {
		goToSelectionDisplay();
	});
	
	function onClickRetry(ev) {
		var gettingProjectsFailed = ev.target;
		
		while (gettingProjectsFailed && !gettingProjectsFailed.classList.contains("gettingProjectsFailed")) {
			gettingProjectsFailed = gettingProjectsFailed.parentElement;
		}
		
		if (!gettingProjectsFailed) {
			return;
		}
		
		var selectedOrganization = gettingProjectsFailed.querySelector(".organization.selected");
		
		if (selectedOrganization) {
			selectProjectDiv.className = "designerWithOrganization";
			getOrganizationProjects(selectedOrganization);			
		} else {
			onClickExport();
		}
	}
	
	[].forEach.call(
			document.querySelectorAll(".retry"),
			function (retry) {
				retry.addEventListener("click", onClickRetry);
			}
	);
	
	[].forEach.call(
			document.querySelectorAll(".zeplinTokenErrorRetry"),
			function (zeplinTokenErrorRetry) {
				zeplinTokenErrorRetry.addEventListener("click", function (ev) {
					getSocket().emit("openZeplin");
					goToSelectionDisplay();
				});
			}
	);

	[].forEach.call(
			document.querySelectorAll(".gotItImPoor"),
			function (gotItImPoor) {
				gotItImPoor.addEventListener("click", function () {
					goToSelectionDisplay();
				});
			}
	);
	
	cancelDensitySelection.addEventListener("click", function () {
		goToSelectionDisplay();
	});
	
	chooseDensity.addEventListener("click", function () {
		var project = projectsDiv.querySelector(".project.selected");
		var projectType = project.dataset.type;
		if (projectType === "osx") {
			projectType = "ios";
		}
		var selectedDensity = document.querySelector('input[type="radio"][name="' + projectType + 'Density"]:checked').value;
		project.dataset.density = selectedDensity;
		importToProject(project);
	});
	
	[].forEach.call(
		document.querySelectorAll('input[type="radio"][name="androidDensity"]'),
		function (phoneRadio) {
			phoneRadio.addEventListener("change", function (ev) {
				var tabletRadio = document.querySelector('input[type="radio"][name="tabletDensity"][value="'+ ev.target.value + '"]');
				if (tabletRadio) {
					tabletRadio.checked = true;
				} else {
					tabletRadio = document.querySelector('input[type="radio"][name="tabletDensity"]:checked');
					if (tabletRadio) {
						tabletRadio.checked = false;
					}
				}
				repaintAndroidDensities();
			});
		}
	);
	
	[].forEach.call(
		document.querySelectorAll('input[type="radio"][name="tabletDensity"]'),
		function (tabletRadio) {
			tabletRadio.addEventListener("change", function (ev) {
				var phoneRadio = document.querySelector('input[type="radio"][name="androidDensity"][value="'+ ev.target.value + '"]');
				if (phoneRadio) {
					phoneRadio.checked = true;
				}
				repaintAndroidDensities();
			});
		}
	);

	updateScreens.checked = (function () {
		var replaceScreens = localStorage.getItem("replaceScreens");
		return replaceScreens && replaceScreens === "true";
	})();
	updateScreens.addEventListener("change", function (ev) {
		localStorage.setItem("replaceScreens", updateScreens.checked);
	});
	
	document.addEventListener("click", function () {
		organizationsDiv.classList.add("hidden");
	});
	
	organizationDropdown.addEventListener("click", function (ev) {
		ev.stopPropagation();
		organizationsDiv.classList.toggle("hidden");
	});
	
	organizationsDiv.addEventListener("click", function (ev) {
		var organization = ev.target;
		
		while (organization && !organization.classList.contains("organization")) {
			organization = organization.parentElement;
		}
		
		if (!organization) {
			return;
		}
		
		ev.stopPropagation();
		
		var prevSelectedOrganization = organizationsDiv.querySelector(".selected");
		if (prevSelectedOrganization) {
			prevSelectedOrganization.classList.remove("selected");
		}
		organization.classList.add("selected");
		
		selectedOrganizationTextInDropdown.textContent = organization.querySelector(".organizationName").textContent;
		selectedOrganizationTextInDropdown.classList.toggle("nonPersonal", organization.dataset.oid !== "user");
		selectProjectDiv.classList.toggle("listingOrganizationProjects", organization.dataset.oid !== "user");
		
		organizationsDiv.classList.add("hidden");
		
		var userCantUploadDesigns = organization.dataset.oid !== "user" && organization.dataset.userRole === "knight";
		body.classList.toggle("userCantUploadDesigns", userCantUploadDesigns);
		body.classList.remove("noProjects");
		importToProjectButton.disabled = true;
		if (!userCantUploadDesigns) {
			getOrganizationProjects(organization);
		}
	});

})();
	
	
